import NextAuth, { User } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";
import { API_URL } from "./constants/url";
import { jwtDecode } from "jwt-decode";

export const { handlers, signIn, signOut, auth } = NextAuth({
  pages: {
    signIn: "/login",
    error: "/login",
  },
  session: {
    strategy: "jwt",
    maxAge: 60 * 60 * 24, // 1-day expiry
  },
  secret: process.env.NEXTAUTH_SECRET,
  debug: process.env.NODE_ENV === "development",
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email" },
        password: { label: "Password", type: "password" },
      },
      async authorize({ email, password }) {
        const url = `${process.env.NEXT_PUBLIC_BACKEND_URL}${API_URL.auth.login}`;
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email, password }),
        });

        if (!response.ok) return null;

        const { data } = await response.json();
        return {
          email: data.email,
          jwt: data.jwt,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account, profile }) {
      // ✅ Handle Google Login
      if (account?.provider === "google") {
        token.email = profile?.email;
        token.name = profile?.name;
        token.picture = profile?.picture;

        // ✅ Send Google ID Token to Backend
        const res = await fetch(`${process.env.NEXT_PUBLIC_BACKEND_URL}/api/v1/auth/google-login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ idToken: account.id_token }),
        });

        if (res.ok) {
          const data = await res.json();
          token.jwt = data.data.jwt; // ✅ Store JWT from backend
        } else {
          console.error("Failed to authenticate with backend");
        }
      }

      return token;
    },
    async session({ session, token }) {
      session.user = {
        email: token.email,
        name: token.name,
        picture: token.picture,
        jwt: token.jwt, // ✅ Store JWT in session
      };
      return session;
    },
  },
});
