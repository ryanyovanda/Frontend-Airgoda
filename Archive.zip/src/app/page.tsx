import { FC } from "react";
import Navbar from "./components/navbar";
const Home: FC = () => {
  return (
    <>
      
        <Navbar/>
      
    </>
  );
};

export default Home;